package Examen;

public class DispositivoNoCompatibleException extends Exception{
    public DispositivoNoCompatibleException(String message) {
        super(message);
    }
}
